SELECT * FROM Hospital_data

---1. Total Number of Patients 

SELECT SUM(Patients_Count) AS Total_Count_of_Patients
FROM Hospital_data;

---2. Average Number of Doctors per Hospital 

SELECT AVG(Doctors_Count) AS Average_Number_of_Doctors_per_Hospital 
FROM Hospital_data;

---3. Top 3 Departments with the Highest Number of Patients

SELECT * FROM Hospital_data
ORDER BY Patients_Count DESC;

---4. Hospital with the Maximum Medical Expenses 
SELECT MAX(Medical_Expenses) AS Maximum_Medical_Expenses
FROM Hospital_data;

---5. Daily Average Medical Expenses 

SELECT Hospital_Name, AVG(Medical_Expenses) AS Avg_Daily_Expenses
FROM Hospital_Data
GROUP BY Hospital_Name
ORDER BY Avg_Daily_Expenses DESC;

---6.Longest Hospital Stay
SELECT Hospital_Name, Patients_Count, Admission_Date, Discharge_Date, 
       DATEDIFF(DAY, Admission_Date, Discharge_Date) AS Stay_Duration
FROM Hospital_Data
ORDER BY Stay_Duration DESC

---7. Total Patients Treated Per City 
SELECT Location AS City, SUM(Patients_Count) AS Total_Patients
FROM Hospital_Data
GROUP BY Location
ORDER BY Total_Patients DESC;


---8. Average Length of Stay Per Department 
SELECT Department, AVG(DATEDIFF(DAY, Admission_Date, Discharge_Date)) AS Avg_Stay_Days
FROM Hospital_Data
GROUP BY Department
ORDER BY Avg_Stay_Days DESC;


---9. Identify the Department with the Lowest Number of Patients 
SELECT Department, SUM(Patients_Count) AS Total_Patients
FROM Hospital_Data
GROUP BY Department
ORDER BY Total_Patients ASC;


---10. Monthly Medical Expenses Report 
SELECT FORMAT(Admission_Date, 'yyyy-MM') AS Month, SUM(Medical_Expenses) AS Total_Expenses
FROM Hospital_Data
GROUP BY FORMAT(Admission_Date, 'yyyy-MM')
ORDER BY Month;
