SELECT * FROM Hospital_data;

SELECT * FROM Hospital_data
WHERE Department='ENT';

SELECT * FROM Hospital_data
WHERE Patients_Count>150;


SELECT * FROM Hospital_data
WHERE Discharge_Date='2023-12-14';

SELECT * FROM Hospital_data
WHERE Admission_Date BETWEEN '2023-12-01' AND '2024-12-31';

SELECT *FROM Hospital_data
WHERE Doctors_Count<60;

SELECT SUM(Doctors_Count) AS Total_Dr
FROM  Hospital_data;