                                        --- CONSTRAINS
 ---Constarins  are use to specify rules for data in table 
---1. NOT NULL,
---2. UNIQE,
---3. PRIMARY KEY , 
---4. FORGEGIN KEY 
---5. DEFULT
---6. CHEAK 


CREATE DATABASE STD_DATA;

USE STD_DATA;

CREATE TABLE student(
rollno INT PRIMARY KEY NOT NULL,
name VARCHAR(20) NOT NULL,
marks INT DEFAULT 45  ,
grade VARCHAR(2),
city VARCHAR UNIQUE
);

SELECT * FROM student;

INSERT INTO student
(rollno,name,marks,grade,city)
VALUES
(101,'akansa','B','karnal')

(102,'ritu',59,'C','panipat'),
(103,'sasi',95,'A','delhi'),
(104,'diksa',62,'B','kolkata'),	
(105,'rani',60,'A','punjab'),
(106,'riki',86,'A','haryana');

---ALTER TABLE student
---ALTER COLUMN city VARCHAR(20);

