                                            ---SQL
---SQL is Structured Query (programming) Language used to interact with relational databases.
---SQL is used to perform CRUD Operations (CRUD = Create, Read, Update, Delete).

                                           ---SQL Commands
--- (DDL :- Data Definition Language) Create, Alter, Rename, Truncate, Drop
--- (DQL :- Data Query Language) Select
--- (DML :- Data Manipulation Language) Insert, Update, Delete
--- (DCL :- Data Control Language) Grant, Revoke (permission to user)
--- (TCL :- Transaction Control Language) Start Transaction, Commit, Rollback

                                          ---KEYS
--- 1. PRIMARY KEY (Unique and cannot be Null)
--- 2. FOREIGN KEY (Refers to Primary Key, it can be Null, duplicate, and it can be multiple)

                                         ---CONSTRAINTS
--- (NOT NULL, UNIQUE, PRIMARY KEY, FOREIGN KEY, DEFAULT, CHECK) -- Constraints are used to specify rules for data in a table

                              ---We are going to learn database and table operations

CREATE DATABASE my_database; 

USE my_database;

CREATE TABLE my_table(
id INT PRIMARY KEY,
name VARCHAR(50),
age INT NOT NULL,
);

---INSURT INTO TABLE 
INSERT INTO my_table
VALUES
(1 , 'SUMIT' , 25);

SELECT * FROM my_table;

---- Prectice 1
---create a database of xyz, table, add inforamtion (1 , adam salary 25000 , 2. bob salary 20000 , 3.casey salary 40000) and view

CREATE DATABASE Xyz_co;
USE Xyz_co

CREATE TABLE emp_info(
Emp_no INT PRIMARY KEY,
Emp_name VARCHAR(20),
emp_salary INT 
);

INSERT INTO emp_info
(Emp_no , Emp_name , emp_salary)
VALUES
(1,'Adam',25000),
(2,'Bob',20000),
(3,'Casey',30000);

SELECT * FROM emp_info;
